﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System.Collections.Generic;

public class HomeViewModel
{
    public string Query { get; set; }
    public List<Meal> Meals { get; set; }
}

public class HomeController : Controller
{
    private readonly IMealService _mealService;

    public HomeController(IMealService mealService)
    {
        _mealService = mealService;
    }

    // Home/Search page
    public async Task<IActionResult> Index(string q)
    {
        try
        {
            List<Meal> meals = null;
            if (!string.IsNullOrWhiteSpace(q))
            {
                meals = await _mealService.SearchMealsAsync(q);
            }

            var vm = new HomeViewModel { Query = q, Meals = meals };
            return View(vm);
        }
        catch
        {
            ViewBag.Error = "Something went wrong while loading meals.";
            return View("Error");
        }
    }

    // Meal details page
    public async Task<IActionResult> Details(string id)
    {
        try
        {
            if (string.IsNullOrEmpty(id)) return BadRequest();

            var meal = await _mealService.GetMealByIdAsync(id);
            if (meal == null) return NotFound();

            return View(meal);
        }
        catch
        {
            ViewBag.Error = "Unable to load meal details.";
            return View("Error");
        }
    }

    // About page
    public IActionResult About()
    {
        return View();
    }

    // Random meal page
    public async Task<IActionResult> Random()
    {
        try
        {
            var meal = await _mealService.GetRandomMealAsync();
            if (meal == null)
            {
                ViewBag.Error = "Unable to fetch a random meal.";
                return View("Error");
            }

            return View("Details", meal);
        }
        catch
        {
            ViewBag.Error = "Something went wrong while fetching a random meal.";
            return View("Error");
        }
    }

   // ForceError testing
    public IActionResult ForceError()
    {
        ViewBag.Error = "⚠️ This is a test error page for demonstration purposes.";
        return View("Error");
    }
}