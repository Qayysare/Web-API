﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

public class MealService : IMealService
{
    private readonly HttpClient _http;
    private readonly string _apiKey;

    public MealService(HttpClient http, IConfiguration config)
    {
        _http = http;
        _apiKey = config["TheMealDb:ApiKey"];

        if (string.IsNullOrWhiteSpace(_apiKey))
        {
            throw new InvalidOperationException(
                "TheMealDB API key is missing. Please configure it in user secrets.");
        }
    }

    private List<Meal> ParseMealsFromJson(string json)
    {
        var result = new List<Meal>();
        using var doc = JsonDocument.Parse(json);

        if (!doc.RootElement.TryGetProperty("meals", out var mealsElem) ||
            mealsElem.ValueKind != JsonValueKind.Array)
            return result;

        foreach (var item in mealsElem.EnumerateArray())
        {
            if (item.ValueKind != JsonValueKind.Object) continue;

            var meal = new Meal
            {
                IdMeal = item.GetProperty("idMeal").GetString(),
                Name = item.GetProperty("strMeal").GetString(),
                Category = item.GetProperty("strCategory").GetString(),
                Area = item.GetProperty("strArea").GetString(),
                Instructions = item.GetProperty("strInstructions").GetString(),
                Thumbnail = item.GetProperty("strMealThumb").GetString(),
                YouTube = item.GetProperty("strYoutube").GetString()
            };

            // gather ingredients 1..20
            for (int i = 1; i <= 20; i++)
            {
                var ingProp = $"strIngredient{i}";
                var measProp = $"strMeasure{i}";

                string ing = null, meas = null;
                if (item.TryGetProperty(ingProp, out var ingVal)) ing = ingVal.GetString();
                if (item.TryGetProperty(measProp, out var measVal)) meas = measVal.GetString();

                if (!string.IsNullOrWhiteSpace(ing))
                    meal.Ingredients.Add((ing.Trim(), meas?.Trim()));
            }

            result.Add(meal);
        }

        return result;
    }

    public async Task<List<Meal>> SearchMealsAsync(string name)
    {
        try
        {
            var path = $"{_apiKey}/search.php?s={Uri.EscapeDataString(name)}";
            var resp = await _http.GetAsync(path);

            if (!resp.IsSuccessStatusCode)
                return new List<Meal>();

            var content = await resp.Content.ReadAsStringAsync();
            return ParseMealsFromJson(content);
        }
        catch (HttpRequestException)
        {
            return new List<Meal>(); // network error
        }
        catch (Exception)
        {
            return new List<Meal>(); // unexpected error
        }
    }

    public async Task<Meal> GetMealByIdAsync(string id)
    {
        try
        {
            var path = $"{_apiKey}/lookup.php?i={Uri.EscapeDataString(id)}";
            var resp = await _http.GetAsync(path);
            if (!resp.IsSuccessStatusCode) return null;

            var content = await resp.Content.ReadAsStringAsync();
            var meals = ParseMealsFromJson(content);
            return meals.Count > 0 ? meals[0] : null;
        }
        catch
        {
            return null;
        }
    }

    public async Task<Meal> GetRandomMealAsync()
    {
        try
        {
            var path = $"{_apiKey}/random.php";
            var resp = await _http.GetAsync(path);
            if (!resp.IsSuccessStatusCode) return null;

            var content = await resp.Content.ReadAsStringAsync();
            var meals = ParseMealsFromJson(content);
            return meals.Count > 0 ? meals[0] : null;
        }
        catch
        {
            return null;
        }
    }
}