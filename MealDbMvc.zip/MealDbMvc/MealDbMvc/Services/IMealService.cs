﻿using System.Collections.Generic;
using System.Threading.Tasks;

public interface IMealService
{
    Task<List<Meal>> SearchMealsAsync(string name);
    Task<Meal> GetMealByIdAsync(string id);
    Task<Meal> GetRandomMealAsync();
}