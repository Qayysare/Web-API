﻿// Models/MealResult.cs
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;

public class MealResult
{
    [JsonPropertyName("meals")]
    public List<JsonElement> MealsJson { get; set; }  // we’ll parse into Meal manually
}