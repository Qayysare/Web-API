﻿// Models/Meal.cs
using System.Collections.Generic;

public class Meal
{
    public string IdMeal { get; set; }
    public string Name { get; set; }
    public string Category { get; set; }
    public string Area { get; set; }
    public string Instructions { get; set; }
    public string Thumbnail { get; set; }
    public string YouTube { get; set; }

    // List of (ingredient, measure)
    public List<(string Ingredient, string Measure)> Ingredients { get; set; }
        = new List<(string, string)>();
}